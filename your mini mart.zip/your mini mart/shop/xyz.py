#   backup for views.py 
#   backup for views.py 
from math import ceil
from sqlite3 import paramstyle
from django.shortcuts import render
from .models import product

def nslides_cal(n) :
    if(n%3 == 0) :
        slides = int(n/3)
    else :
        slides = int(n/3) + 1
    return slides    

def index(request) :
    image_tags = []
    products = product.objects.all()
    mens_fashion = []
    electro = []
    sports = []
    daily_use = []
    for i in products :
        if i.catagory == "men fashion" :
            mens_fashion.append(i)
        elif i.catagory == "electronics" :
            electro.append(i)
        elif i.catagory == "sports" :
            sports.append(i)
        elif i.catagory == "grocery" :
            daily_use.append(i)
        else :
            break                

    nprod = len(products)
    nMF = len(mens_fashion)
    nsports = len(sports)
    nelectro = len(electro)
    ndaily = len(daily_use)
    nslidesProd = nslides_cal(nprod)
    nslidesMF = nslides_cal(nMF)
    nslidesSports = nslides_cal(nsports)
    nslidesDaily = nslides_cal(ndaily)
    nslidesElectro = nslides_cal(nelectro)
    
    iterator= range(0,3)    
    allprod = [
        [products,range(0,nslidesProd),nslidesProd],
        [mens_fashion,range(0,nslidesMF),nslidesMF],
        [electro,range(0,nslidesElectro),nslidesElectro],
        [sports,range(0,nslidesSports),nslidesSports],
        [daily_use,range(0,nslidesDaily),nslidesDaily]
    ]
    # params = {'prod' : prod,'no_of_slide' : nslides , 'range' : range(0,nslides),'iterator' : range(0,3)}
    params = {'allprod' : allprod}
    return render(request,'shop/index.html',params)

def view_product(request) :
    products = product.objects.all()
    lable_ids=[]
    for i in products:
        lable_ids.append(i.product_name)
    if 'view' in request.GET :
        value = request.GET.get("view")
    elif 'add to cart' in request.GET:
        value = request.GET.get("add to cart")    
   
    for i in products:
        if value == i.product_name :
            params = {'product' : i}
    return render(request,'shop/view_product.html',params)