from django.contrib import admin

# Register your models here.
from .models import cart, product, query, sign_in
admin.site.register(product)
admin.site.register(query)
admin.site.register(sign_in)
admin.site.register(cart)
fields = ['image_tag']
readonly_fields = ['image_tag']